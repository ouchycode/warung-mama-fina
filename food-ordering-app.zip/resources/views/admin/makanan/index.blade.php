@section('title', 'Daftar Barang | Warung Mama Fina')

<x-app-layout>
    <x-slot name="header">
        <h2 class="text-3xl font-extrabold text-emerald-900 leading-tight tracking-tight">
            Daftar Barang
        </h2>
    </x-slot>

    <div class="py-8 max-w-5xl mx-auto">
        @if (session('status'))
            <div class="mb-4 bg-emerald-100 border border-emerald-300 text-emerald-800 px-4 py-3 rounded shadow">
                {{ session('status') }}
            </div>
        @endif

        <div class="mb-4 text-right">
            <a href="{{ route('admin.makanan.create') }}"
               class="bg-emerald-700 hover:bg-emerald-800 text-white py-2 px-4 rounded-lg shadow transition">
                Tambah Barang
            </a>
        </div>

        <div class="bg-white shadow rounded-lg border border-emerald-200 overflow-x-auto">
            <table class="min-w-full text-sm text-left border-collapse">
                <thead class="bg-emerald-50 text-emerald-700 uppercase text-xs tracking-wider">
                    <tr>
                        <th class="px-5 py-3 w-24">Gambar</th>
                        <th class="px-5 py-3">Nama</th>
                        <th class="px-5 py-3">Kategori</th>
                        <th class="px-5 py-3 text-right">Harga</th>
                        <th class="px-5 py-3 text-right w-48">Aksi</th>
                    </tr>
                </thead>
                <tbody class="text-emerald-900 divide-y divide-emerald-100">
                    @forelse ($makanan as $item)
                        <tr class="even:bg-emerald-50 hover:bg-emerald-100 transition">
                            <td class="px-5 py-3">
                                @if ($item->gambar)
                                    <img src="{{ asset('storage/' . $item->gambar) }}"
                                         alt="gambar"
                                         class="w-16 h-16 object-cover rounded-lg shadow border border-emerald-300">
                                @else
                                    <span class="text-emerald-400 italic">Tidak ada</span>
                                @endif
                            </td>
                            <td class="px-5 py-3 font-medium">{{ $item->nama }}</td>
                            <td class="px-5 py-3">{{ $item->kategori ?? '-' }}</td>
                            <td class="px-5 py-3 text-right font-mono">Rp{{ number_format($item->harga) }}</td>
                            <td class="px-5 py-3">
                                <div class="flex justify-end gap-2">
                                    <a href="{{ route('admin.makanan.edit', $item) }}"
                                       class="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2 rounded-md shadow-sm transition">
                                        Edit
                                    </a>

                                    <form action="{{ route('admin.makanan.destroy', $item) }}" method="POST" class="inline-block"
                                          onsubmit="return confirm('Yakin ingin menghapus barang ini?')">
                                        @csrf @method('DELETE')
                                        <button type="submit"
                                                class="bg-red-600 hover:bg-red-700 text-white font-semibold px-4 py-2 rounded-md shadow-sm transition">
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center text-emerald-400 py-6 italic">Belum ada barang tersedia.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</x-app-layout>
