@section('title', 'Daftar Ulasan | Warung Mama Fina')

<x-app-layout>
    <x-slot name="header">
        <h2 class="text-3xl font-extrabold text-emerald-900 leading-tight tracking-tight">
            Daftar Ulasan
        </h2>
    </x-slot>

    <div class="py-12 max-w-5xl mx-auto px-6">
        @if (session('status'))
            <div class="mb-6 bg-emerald-100 border border-emerald-300 text-emerald-800 px-4 py-3 rounded-lg shadow">
                {{ session('status') }}
            </div>
        @endif

        <div class="bg-white shadow-md rounded-lg border border-emerald-200 overflow-x-auto">
            <table class="w-full table-auto text-sm text-left border-collapse">
                <thead class="bg-emerald-50 text-emerald-700 uppercase text-xs tracking-wide">
                    <tr>
                        <th class="px-5 py-3">Nama Pelanggan</th>
                        <th class="px-5 py-3">ID Pesanan</th>
                        <th class="px-5 py-3">Rating</th>
                        <th class="px-5 py-3">Komentar</th>
                        <th class="px-5 py-3">Tanggal</th>
                    </tr>
                </thead>
                <tbody class="text-emerald-900 divide-y divide-emerald-100">
                    @forelse ($ulasans as $ulasan)
                        <tr class="even:bg-emerald-50 hover:bg-emerald-100 transition">
                            <td class="px-5 py-3 font-medium">{{ $ulasan->pelanggan->name }}</td>
                            <td class="px-5 py-3 font-mono text-emerald-600">#{{ $ulasan->pesanan->id }}</td>
                            <td class="px-5 py-3">
                                <span class="text-yellow-500 font-semibold">{{ $ulasan->rating }} ⭐</span>
                            </td>
                            <td class="px-5 py-3 max-w-xs break-words text-emerald-800">
                                {{ \Illuminate\Support\Str::limit($ulasan->komentar, 120, '...') ?? '-' }}
                            </td>
                            <td class="px-5 py-3 text-sm text-emerald-700">
                                {{ $ulasan->created_at->translatedFormat('d F Y, H:i') }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center text-emerald-400 py-6 italic">Belum ada ulasan yang masuk.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</x-app-layout>
