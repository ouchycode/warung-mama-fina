<?php $__env->startSection('title', 'Menu | Warung Mama Fina'); ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-3xl font-extrabold text-emerald-900 leading-tight tracking-tight">
            Menu Warung
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto px-6 lg:px-8" x-data="pesananHandler()">
            
            <div class="mb-6">
                <form method="GET" action="<?php echo e(route('pelanggan.pesan')); ?>" class="flex flex-col sm:flex-row sm:items-end gap-4">
                    <div class="w-full sm:w-1/2">
                        <label for="kategori" class="block text-sm font-medium text-emerald-800 mb-1">Pilih Kategori:</label>
                        <div class="relative">
                            <select name="kategori" id="kategori"
                                    onchange="this.form.submit()"
                                    class="appearance-none w-full border border-emerald-300 bg-white rounded-lg px-4 py-2 pr-10 text-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-600 shadow-sm transition">
                                <option value="">-- Semua Kategori --</option>
                                <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kategori); ?>" <?php echo e(request('kategori') === $kategori ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst($kategori)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="absolute inset-y-0 right-3 flex items-center pointer-events-none">
                                <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" stroke-width="2"
                                     viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            
            <?php if(session('status')): ?>
                <div class="mb-6 bg-emerald-100 border border-emerald-300 text-emerald-800 px-4 py-3 rounded-lg shadow">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="mb-6 bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-lg shadow">
                    <ul class="list-disc list-inside text-sm">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <div class="bg-white border border-emerald-200 rounded-2xl p-8 shadow-xl">
                <h3 class="text-xl font-semibold text-emerald-800 mb-6">
                    Pilih produk yang ingin Anda beli:
                </h3>

                <form method="POST" action="<?php echo e(route('pelanggan.simpan')); ?>" x-ref="form">
                    <?php echo csrf_field(); ?>

                    <?php $__empty_1 = true; $__currentLoopData = $makanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="mb-5 p-5 bg-white border border-emerald-200 rounded-xl shadow-sm hover:shadow-md transition">
                            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                <div class="flex items-start gap-4">
                                    <?php if($item->gambar): ?>
                                        <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" alt="<?php echo e($item->nama); ?>"
                                             class="w-24 h-24 object-cover rounded-lg border border-emerald-300">
                                    <?php else: ?>
                                        <div class="w-24 h-24 bg-emerald-50 flex items-center justify-center text-emerald-400 text-sm border rounded-lg">
                                            Tidak ada gambar
                                        </div>
                                    <?php endif; ?>

                                    <div>
                                        <h4 class="text-lg font-bold text-emerald-900"><?php echo e($item->nama); ?></h4>
                                        <p class="text-sm text-emerald-700">Harga: Rp<?php echo e(number_format($item->harga)); ?></p>
                                        <p class="text-xs text-emerald-500 italic">Kategori: <?php echo e($item->kategori ?? '-'); ?></p>
                                    </div>
                                </div>

                                <div class="flex items-center gap-2">
                                    <input type="hidden" name="makanan_id[]" value="<?php echo e($item->id); ?>">
                                    <input type="number"
                                           name="jumlah[]"
                                           min="0"
                                           placeholder="0"
                                           class="w-20 border border-emerald-300 rounded-md text-center py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                                           x-model.number="jumlah[<?php echo e($index); ?>]"
                                           @input="hitungTotal()"
                                    >
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-center text-emerald-500 italic">Menu belum tersedia untuk kategori ini.</p>
                    <?php endif; ?>

                    
<div class="mt-6">
    <label for="alamat_pengantaran" class="block font-semibold text-emerald-800 mb-2">Alamat Tujuan Pengantaran:</label>
    <textarea name="alamat_pengantaran" id="alamat_pengantaran"
              rows="3"
              required
              class="w-full border border-emerald-300 rounded-md px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
              placeholder="Contoh: Jl. Melati No. 123, RT 04 RW 02, Kel. Sukamaju, Kec. Sukaraja">
        <?php echo e(old('alamat_pengantaran')); ?>

    </textarea>
    <?php $__errorArgs = ['alamat_pengantaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-sm text-red-500 mt-1 block"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


                    
                    <div class="mt-6">
                        <label class="block font-semibold text-emerald-800 mb-2">Metode Pembayaran:</label>
                        <select name="metode_pembayaran" required
                                class="w-full border border-emerald-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600">
                            <option value="">-- Pilih --</option>
                            <option value="cod">Bayar di Tempat (COD)</option>
                            <option value="transfer">Transfer Bank (Demo)</option>
                        </select>
                    </div>

                    
                    <div class="mt-8 text-right text-lg font-semibold text-emerald-800">
                        Total Belanja:
                        <span class="text-emerald-700">
                            Rp <span x-text="formatRupiah(total)"></span>
                        </span>
                        <div class="text-sm text-emerald-500" x-show="jumlah.filter(j => j > 0).length > 0">
                            (<span x-text="jumlah.filter(j => j > 0).length"></span> item dipilih)
                        </div>
                    </div>

                    
                    <div class="mt-8 text-center">
                        <button type="button"
                                @click="konfirmasiSubmit"
                                :disabled="total <= 0"
                                class="bg-emerald-700 hover:bg-emerald-800 text-white text-base font-semibold py-3 px-8 rounded-lg shadow-md transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed">
                            Lanjutkan Pemesanan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
    <script>
        function pesananHandler() {
            return {
                jumlah: [],
                total: 0,
                hitungTotal() {
                    const hargaList = <?php echo json_encode($makanan->pluck('harga')->values(), 15, 512) ?>;
                    this.total = this.jumlah.reduce((sum, qty, i) => {
                        const harga = hargaList[i] || 0;
                        return sum + (parseInt(qty) > 0 ? harga * parseInt(qty) : 0);
                    }, 0);
                },
                formatRupiah(value) {
                    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                },
                konfirmasiSubmit() {
                    if (this.total > 0) {
                        Swal.fire({
                            title: 'Konfirmasi Pemesanan',
                            html: `Total belanja: <strong>Rp ${this.formatRupiah(this.total)}</strong><br><br>Yakin ingin melanjutkan?`,
                            icon: 'question',
                            showCancelButton: true,
                            confirmButtonColor: '#047857',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Ya, Pesan',
                            cancelButtonText: 'Batal'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                this.$refs.form.submit();
                            }
                        });
                    }
                }
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\food-ordering-app\resources\views/pelanggan/pesan.blade.php ENDPATH**/ ?>