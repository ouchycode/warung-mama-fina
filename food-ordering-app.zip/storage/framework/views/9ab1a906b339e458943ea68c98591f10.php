<?php $__env->startSection('title', 'Daftar Barang | Warung Mama Fina'); ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-3xl font-extrabold text-emerald-900 leading-tight tracking-tight">
            Daftar Barang
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8 max-w-5xl mx-auto">
        <?php if(session('status')): ?>
            <div class="mb-4 bg-emerald-100 border border-emerald-300 text-emerald-800 px-4 py-3 rounded shadow">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="mb-4 text-right">
            <a href="<?php echo e(route('admin.makanan.create')); ?>"
               class="bg-emerald-700 hover:bg-emerald-800 text-white py-2 px-4 rounded-lg shadow transition">
                Tambah Barang
            </a>
        </div>

        <div class="bg-white shadow rounded-lg border border-emerald-200 overflow-x-auto">
            <table class="min-w-full text-sm text-left border-collapse">
                <thead class="bg-emerald-50 text-emerald-700 uppercase text-xs tracking-wider">
                    <tr>
                        <th class="px-5 py-3 w-24">Gambar</th>
                        <th class="px-5 py-3">Nama</th>
                        <th class="px-5 py-3">Kategori</th>
                        <th class="px-5 py-3 text-right">Harga</th>
                        <th class="px-5 py-3 text-right w-48">Aksi</th>
                    </tr>
                </thead>
                <tbody class="text-emerald-900 divide-y divide-emerald-100">
                    <?php $__empty_1 = true; $__currentLoopData = $makanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="even:bg-emerald-50 hover:bg-emerald-100 transition">
                            <td class="px-5 py-3">
                                <?php if($item->gambar): ?>
                                    <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                                         alt="gambar"
                                         class="w-16 h-16 object-cover rounded-lg shadow border border-emerald-300">
                                <?php else: ?>
                                    <span class="text-emerald-400 italic">Tidak ada</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-3 font-medium"><?php echo e($item->nama); ?></td>
                            <td class="px-5 py-3"><?php echo e($item->kategori ?? '-'); ?></td>
                            <td class="px-5 py-3 text-right font-mono">Rp<?php echo e(number_format($item->harga)); ?></td>
                            <td class="px-5 py-3">
                                <div class="flex justify-end gap-2">
                                    <a href="<?php echo e(route('admin.makanan.edit', $item)); ?>"
                                       class="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2 rounded-md shadow-sm transition">
                                        Edit
                                    </a>

                                    <form action="<?php echo e(route('admin.makanan.destroy', $item)); ?>" method="POST" class="inline-block"
                                          onsubmit="return confirm('Yakin ingin menghapus barang ini?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="bg-red-600 hover:bg-red-700 text-white font-semibold px-4 py-2 rounded-md shadow-sm transition">
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-emerald-400 py-6 italic">Belum ada barang tersedia.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\food-ordering-app\resources\views/admin/makanan/index.blade.php ENDPATH**/ ?>