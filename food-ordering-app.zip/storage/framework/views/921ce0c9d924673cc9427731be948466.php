<?php $__env->startSection('title', 'Daftar Ulasan | Warung Mama Fina'); ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-3xl font-extrabold text-emerald-900 leading-tight tracking-tight">
            Daftar Ulasan
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 max-w-5xl mx-auto px-6">
        <?php if(session('status')): ?>
            <div class="mb-6 bg-emerald-100 border border-emerald-300 text-emerald-800 px-4 py-3 rounded-lg shadow">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="bg-white shadow-md rounded-lg border border-emerald-200 overflow-x-auto">
            <table class="w-full table-auto text-sm text-left border-collapse">
                <thead class="bg-emerald-50 text-emerald-700 uppercase text-xs tracking-wide">
                    <tr>
                        <th class="px-5 py-3">Nama Pelanggan</th>
                        <th class="px-5 py-3">ID Pesanan</th>
                        <th class="px-5 py-3">Rating</th>
                        <th class="px-5 py-3">Komentar</th>
                        <th class="px-5 py-3">Tanggal</th>
                    </tr>
                </thead>
                <tbody class="text-emerald-900 divide-y divide-emerald-100">
                    <?php $__empty_1 = true; $__currentLoopData = $ulasans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="even:bg-emerald-50 hover:bg-emerald-100 transition">
                            <td class="px-5 py-3 font-medium"><?php echo e($ulasan->pelanggan->name); ?></td>
                            <td class="px-5 py-3 font-mono text-emerald-600">#<?php echo e($ulasan->pesanan->id); ?></td>
                            <td class="px-5 py-3">
                                <span class="text-yellow-500 font-semibold"><?php echo e($ulasan->rating); ?> ⭐</span>
                            </td>
                            <td class="px-5 py-3 max-w-xs break-words text-emerald-800">
                                <?php echo e(\Illuminate\Support\Str::limit($ulasan->komentar, 120, '...') ?? '-'); ?>

                            </td>
                            <td class="px-5 py-3 text-sm text-emerald-700">
                                <?php echo e($ulasan->created_at->translatedFormat('d F Y, H:i')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-emerald-400 py-6 italic">Belum ada ulasan yang masuk.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\food-ordering-app\resources\views/admin/ulasan/index.blade.php ENDPATH**/ ?>