<?php $__env->startSection('title', 'Lacak Pengiriman | Warung Mama Fina'); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-3xl font-extrabold text-emerald-900 leading-tight tracking-tight">
            Lacak Pengiriman
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto px-6 lg:px-8">
            <div class="bg-white border border-emerald-200 rounded-2xl shadow-xl p-8 transition-all duration-300">

                
                <?php if(session('status')): ?>
                    <div class="mb-6 bg-emerald-50 border border-emerald-300 text-emerald-800 px-4 py-3 rounded-lg shadow">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <?php if($pesanan): ?>
                    <h3 class="text-xl font-bold text-emerald-800 mb-4">Informasi Pesanan Anda</h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-emerald-800 mb-4">
                        <div><span class="font-semibold">ID Pesanan:</span> #<?php echo e($pesanan->id); ?></div>
                        <div><span class="font-semibold">Tanggal Pemesanan:</span> <?php echo e(\Carbon\Carbon::parse($pesanan->waktu_pesan)->translatedFormat('d F Y, H:i')); ?></div>
                        <div><span class="font-semibold">Metode Pembayaran:</span> 
                            <span class="capitalize">
                                <?php echo e($pesanan->metode_pembayaran === 'cod' ? 'Bayar di Tempat (COD)' : 'Transfer Bank (Demo)'); ?>

                            </span>
                        </div>
                        <div><span class="font-semibold">Alamat Pengantaran:</span> <?php echo e($pesanan->alamat_pengantaran); ?></div>
                        <div class="sm:col-span-2">
                            <span class="font-semibold">Status:</span>
                            <span class="ml-2 inline-block px-3 py-1 rounded-full text-white text-xs font-medium
                                <?php if($pesanan->status_pesanan === 'menunggu'): ?> 
                                    bg-yellow-600 
                                <?php elseif($pesanan->status_pesanan === 'diproses'): ?> 
                                    bg-orange-600 
                                <?php elseif($pesanan->status_pesanan === 'dikirim'): ?> 
                                    bg-blue-700 
                                <?php elseif($pesanan->status_pesanan === 'selesai'): ?> 
                                    bg-emerald-700 
                                <?php else: ?> 
                                    bg-gray-500 
                                <?php endif; ?>">
                                <?php echo e(ucfirst($pesanan->status_pesanan)); ?>

                            </span>
                        </div>
                    </div>

                    <hr class="my-4 border-emerald-200">

                    <h4 class="text-md font-semibold text-emerald-800 mb-2">Detail Pembelian</h4>
                    <ul class="text-emerald-700 text-sm space-y-2">
                        <?php $__currentLoopData = $pesanan->makanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $makanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex justify-between">
                                <span><?php echo e($makanan->nama); ?> x <?php echo e($makanan->pivot->jumlah); ?></span>
                                <span>Rp<?php echo e(number_format($makanan->harga * $makanan->pivot->jumlah, 0, ',', '.')); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <div class="mt-4 border-t pt-4 text-right font-bold text-emerald-900">
                        Total: Rp<?php echo e(number_format($pesanan->makanan->sum(fn($m) => $m->harga * $m->pivot->jumlah), 0, ',', '.')); ?>

                    </div>

                    
                    <?php if($pesanan->status_pesanan === 'menunggu'): ?>
                        <form action="<?php echo e(route('pelanggan.batal', $pesanan->id)); ?>" method="POST" class="mt-6 text-center">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                    onclick="return confirm('Yakin ingin membatalkan pesanan ini?')"
                                    class="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-2 rounded-lg shadow-md transition duration-300">
                                Batalkan Pesanan
                            </button>
                        </form>
                    <?php endif; ?>

                    
                    <?php if($pesanan->status_pesanan === 'selesai'): ?>
                        <div class="mt-6">
                            <?php if($pesanan->ulasan): ?>
                                <h4 class="text-lg font-semibold text-emerald-800 mb-2">Ulasan Anda</h4>
                                <div class="bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-sm text-emerald-700">
                                    <div class="mb-2"><strong>Rating:</strong> <?php echo e($pesanan->ulasan->rating); ?> / 5</div>
                                    <?php if($pesanan->ulasan->komentar): ?>
                                        <div><strong>Komentar:</strong> <?php echo e($pesanan->ulasan->komentar); ?></div>
                                    <?php else: ?>
                                        <div class="italic text-emerald-500">Tanpa komentar.</div>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <h4 class="text-lg font-semibold text-emerald-800 mb-4">Beri Ulasan</h4>

                                <form action="<?php echo e(route('pelanggan.simpan-ulasan', $pesanan->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="mb-4">
                                        <label class="block text-emerald-800 font-medium">Rating</label>
                                        <input type="number" name="rating" min="1" max="5" class="w-full border border-emerald-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600" required>
                                        <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-4">
                                        <label class="block text-emerald-800 font-medium">Komentar</label>
                                        <textarea name="komentar" class="w-full border border-emerald-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600" rows="3" placeholder="Tulis komentar di sini (opsional)"></textarea>
                                        <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <button type="submit" class="bg-emerald-700 hover:bg-emerald-800 text-white px-6 py-3 rounded-lg shadow-md transition duration-300">
                                        Kirim Ulasan
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="text-center py-16 text-emerald-500 text-sm italic">
                        Belum ada pesanan untuk dilacak.
                    </div>
                <?php endif; ?>

                <div class="mt-8 text-center">
                    <a href="<?php echo e(route('pelanggan.pesan')); ?>"
                       class="inline-block bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-2 px-6 rounded-lg shadow-md transition duration-300">
                        Buat Pesanan Baru
                    </a>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\food-ordering-app\resources\views/pelanggan/lacak.blade.php ENDPATH**/ ?>