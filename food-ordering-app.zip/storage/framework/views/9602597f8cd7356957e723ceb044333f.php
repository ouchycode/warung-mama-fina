<?php $__env->startSection('title', 'Beranda Pelanggan | Warung Mama Fina'); ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-3xl font-extrabold text-emerald-900 leading-tight tracking-tight">
            Beranda Pelanggan
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-6xl mx-auto px-6 lg:px-8">
            <div class="bg-white shadow-xl rounded-2xl overflow-hidden border border-emerald-200">
                <div class="p-8 sm:p-10">
                    <!-- Greeting and Introduction -->
                    <h3 class="text-3xl font-extrabold text-emerald-900 mb-6 tracking-tight">Selamat datang, <?php echo e(Auth::user()->name); ?>!</h3>
                    <p class="text-emerald-700 text-lg mb-8">
                        Terima kasih telah berbelanja di <strong>Warung Mama Fina</strong>. Di sini Anda bisa memesan kebutuhan harian, melihat status pengiriman, dan mengecek riwayat pesanan dengan mudah.
                    </p>

                    <!-- Action Buttons -->
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
                        <a href="<?php echo e(route('pelanggan.pesan')); ?>"
                           class="group flex items-center justify-center gap-4 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-4 px-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105 hover:shadow-lg">
                            <span class="text-lg font-medium">Belanja Sekarang</span>
                        </a>
                        <a href="<?php echo e(route('pelanggan.lacak')); ?>"
                           class="group flex items-center justify-center gap-4 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-4 px-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105 hover:shadow-lg">
                            <span class="text-lg font-medium">Lacak Kiriman</span>
                        </a>
                        <a href="<?php echo e(route('pelanggan.riwayat')); ?>"
                           class="group flex items-center justify-center gap-4 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold py-4 px-8 rounded-xl shadow-md transition duration-300 transform hover:scale-105 hover:shadow-lg">
                            <span class="text-lg font-medium">Cek Riwayat</span>
                        </a>
                    </div>

                    <!-- Pesanan Terakhir -->
                    <?php if($pesanan): ?>
                        <div class="bg-white border border-emerald-300 rounded-lg p-6 mb-8 shadow-lg">
                            <h4 class="text-xl font-semibold text-emerald-800 mb-4">Pesanan Terakhir</h4>
                            <ul class="text-emerald-700 text-sm space-y-2">
                                <li><strong>Status:</strong>
                                    <span class="inline-block px-3 py-1 rounded-full text-white font-medium text-xs
                                        <?php if($pesanan->status_pesanan === 'menunggu'): ?> 
                                            bg-yellow-600 
                                        <?php elseif($pesanan->status_pesanan === 'diproses'): ?> 
                                            bg-orange-600 
                                        <?php elseif($pesanan->status_pesanan === 'dikirim'): ?> 
                                            bg-blue-700 
                                        <?php elseif($pesanan->status_pesanan === 'selesai'): ?> 
                                            bg-emerald-700 
                                        <?php else: ?> 
                                            bg-gray-500 
                                        <?php endif; ?>">
                                        <?php echo e(ucfirst($pesanan->status_pesanan)); ?>

                                    </span>
                                </li>
                                <li><strong>Waktu Pemesanan:</strong>
                                    <?php echo e(\Carbon\Carbon::parse($pesanan->waktu_pesan)->translatedFormat('d F Y, H:i')); ?>

                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-emerald-500 text-sm mt-10 italic">
                            Anda belum melakukan pemesanan.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\food-ordering-app\resources\views/pelanggan/dashboard.blade.php ENDPATH**/ ?>